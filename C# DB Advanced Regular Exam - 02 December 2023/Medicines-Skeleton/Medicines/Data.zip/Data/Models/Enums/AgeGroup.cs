﻿using Medicines.Data.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.Data.Models.Enums
{
    public enum AgeGroup
    {
        Child,
        Adult,
        Senior
    }
}
