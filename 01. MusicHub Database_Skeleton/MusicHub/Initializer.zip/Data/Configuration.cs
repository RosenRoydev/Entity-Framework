﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-L2KK2IT\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True;
       Trust Server Certificate = True;";
    }
}
