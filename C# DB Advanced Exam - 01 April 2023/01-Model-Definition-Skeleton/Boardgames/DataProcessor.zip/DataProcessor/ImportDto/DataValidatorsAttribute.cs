﻿namespace Boardgames.DataProcessor.ImportDto
{
    internal class DataValidatorsAttribute : Attribute
    {
    }
}