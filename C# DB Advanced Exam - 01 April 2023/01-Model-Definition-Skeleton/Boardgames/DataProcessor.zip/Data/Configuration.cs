﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-L2KK2IT\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
