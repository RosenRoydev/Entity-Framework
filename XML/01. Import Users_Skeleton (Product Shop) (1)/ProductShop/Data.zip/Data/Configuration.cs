﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-L2KK2IT\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
