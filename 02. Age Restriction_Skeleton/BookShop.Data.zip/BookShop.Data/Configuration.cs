﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-L2KK2IT\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
